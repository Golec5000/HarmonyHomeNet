# Harmony Home Net

## Opis projektu
Projekt **Harmony Home Net** to system zarządzania wspólnotą mieszkaniową, który umożliwia obsługę użytkowników, mieszkań, dokumentów, głosowań, płatności oraz innych aspektów związanych z zarządzaniem nieruchomościami. System został stworzony jako prototyp, ale zawiera kluczowe funkcjonalności potrzebne do wdrożenia w rzeczywistym środowisku.

---

## Zawartość archiwum
Archiwum projektu zawiera następujące elementy:

1. **backend/** - Kod źródłowy backendu aplikacji w języku Java (Spring Boot).
2. **frontend/** - Kod źródłowy frontendowej aplikacji (React.js).
3. **docker-compose.yml** - Plik konfiguracyjny Docker Compose do uruchamiania aplikacji w środowisku kontenerowym.
4. **README.md** - Niniejszy plik z instrukcjami.

---

## Wymagania systemowe
1. **Docker** i **Docker Compose** (zalecana wersja: najnowsza stabilna).
2. Minimum 2 GB wolnej przestrzeni dyskowej.
3. Połączenie z Internetem dla pobrania obrazów Dockera.

---

## Instrukcja wdrożeniowa
1. **Krok 1: Przygotowanie środowiska**
    - Upewnij się, że Docker i Docker Compose są zainstalowane na Twoim systemie.
    - Pobierz i rozpakuj archiwum projektu.

2. **Krok 2: Konfiguracja pliku `docker-compose.yml`**
    - Otwórz plik `docker-compose.yml` i uzupełnij wymagane dane w sekcji `environment`, szczególnie:
        - Dane logowania do konta e-mail:
          ```
          SPRING_MAIL_USERNAME: [Twój email]
          SPRING_MAIL_PASSWORD: [Twoje hasło]
          ```
        - Dane super administratora:
          ```
          SUPER_ADMIN_FIRST_NAME: [Imię]
          SUPER_ADMIN_LAST_NAME: [Nazwisko]
          SUPER_ADMIN_EMAIL: [Email admina]
          SUPER_ADMIN_PASSWORD: [Hasło admina]
          SUPER_ADMIN_PHONE: [Numer telefonu]
          ```

3. **Krok 3: Uruchomienie aplikacji**
    - Przejdź do głównego katalogu projektu (gdzie znajduje się `docker-compose.yml`).
    - Uruchom aplikację za pomocą komendy:
      ```
      docker-compose up --build
      ```
    - Poczekaj, aż kontenery zostaną uruchomione. Backend uruchomi się na porcie `8444`, a frontend na porcie `3000`.

4. **Krok 4: Pierwsze logowanie**
    - Po uruchomieniu systemu przejdź do przeglądarki i otwórz adres:
        - **Frontend:** `http://localhost:3000/welcome-home`
    - Zaloguj się przy użyciu danych super administratora ustawionych w pliku `docker-compose.yml`.

5. **Krok 5: Dodanie danych**
    - W panelu aplikacji dodaj użytkowników, mieszkania i inne zasoby, korzystając z przygotowanego interfejsu.

---

## Dodatkowe informacje
1. **Plik backendu**:
    - Backend jest zbudowany w oparciu o Spring Boot i konfiguruje bazę danych PostgreSQL w kontenerze Dockera.
    - RSA klucze do zabezpieczeń JWT są generowane automatycznie podczas budowy obrazu Dockera.

2. **Plik frontendowy**:
    - Frontend uruchamia się w środowisku deweloperskim (`npm run dev`) i nasłuchuje na porcie `3000`.
    - W przyszłości zalecana jest optymalizacja dla środowiska produkcyjnego.

3. **Baza danych**:
    - PostgreSQL jest domyślnym serwerem bazodanowym. Dane logowania znajdują się w pliku `docker-compose.yml`:
      ```
      POSTGRES_USER: user
      POSTGRES_PASSWORD: admin
      POSTGRES_DB: HarmonyHomeNet_DB
      ```

4. **E-mail**:
    - Aplikacja wykorzystuje usługę Gmail do wysyłania e-maili. Upewnij się, że Twój adres Gmail ma włączone hasła aplikacji.
